<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/main.css">
    <script src="js/jsmain.js"></script>
    <title>Votre Site Web</title>
</head>
<body>

<header class="navbar" id="navbar">
    <nav>
        <ul>
            <li><a href="#home">ACCUEIL</a></li>
            <li><a href="#news">ESPECES</a></li>
            <li><a href="#collection">MA COLLECTION</a></li>
            <li><a href="#inscription">INSCRIPTION</a></li>
        </ul>
    </nav>
</header>

<main>
    <section class="bloc-haut">
        <div class="carousel-container">
            <div class="carousel-slide">
                <img src="img/banner1.jpg">
                <img class="overlay-image" src="img/biopedia.png" alt="Overlay Image">
            </div>
            <div class="carousel-slide">
                <img src="img/banner3.jpg">
                <img class="overlay-image" src="img/biopedia.png" alt="Overlay Image">
            </div>
            <div class="carousel-slide">
                <img src="img/banner4.jpg">
                <img class="overlay-image" src="img/biopedia.png" alt="Overlay Image">
            </div>
            <div class="carousel-slide">
                <img src="img/banner5.jpg">
                <img class="overlay-image" src="img/biopedia.png" alt="Overlay Image">
            </div>
        </div>
    </section>





    <section class="partenaire">
  <div class="container">
    <div class="bloc-image">
      <div class="partenaire-item">
        <a href="https://mag.polyvore.tn/animaux-terrestres-types-caracteristiques-et-exemples">
          <img class="taille" src="img/terre.jpeg" alt="Logo 1">
          <p>"Plongez dans le monde des animaux terrestres et découvrez leurs secrets cachés."</p>
        </a>
      </div>

      <div class="partenaire-item">
        <a href="https://www.projetecolo.com/animaux-marins-caracteristiques-types-et-liste-51.html">
          <img class="taille" src="img/mer.jpeg" alt="Logo 2">
          <p>"Explorez les mystères des profondeurs marines et découvrez la magie de la vie sous-marine."</p>
        </a>
      </div>

      <div class="partenaire-item">
        <a href="https://www.planeteanimal.com/animaux-aeriens-liste-et-caracteristiques-2567.html">
          <img class="taille" src="img/air.jpeg" alt="Logo 3">
          <p>"Envolez-vous vers le royaume céleste des animaux de l'air et découvrez leurs vols majestueux."</p>
        </a>
      </div>

      <div class="partenaire-item">
        <a href="https://www.encyclopedie-environnement.org">
          <img class="taille" src="img/environnement.jpeg" alt="Logo 4">
          <p>"Protégeons notre planète, une action à la fois, pour un avenir plus vert et plus durable."</p>
        </a>
      </div>
    </div>
  </div>
</section>





    <section class="info-section">
        <div class="bloc-image-texte">
            <img src="img/image1.png" alt="Image 1">
            <p>«Mobilisons-nous en faveur de la préservation de la vie animale et de la résolution des problèmes environnementaux grâce à notre initiative "À propos de la créature" » </p>
        </div>

        <div class="bloc-image-texte">
            <p>Plongez dans l'univers fascinant de la faune française en explorant nos fiches détaillées sur une variété d'espèces. Apprenez à connaître ces créatures extraordinaires tout en comprenant les défis environnementaux auxquels elles font face. Ensemble, engageons-nous à protéger ces joyaux de la biodiversité et à résoudre les enjeux qui menacent leur existence.</p>
            <img src="img/image2.png" alt="Image 2">
        </div>

        <div class="bloc-image-texte">
            <p>Rejoignez notre communauté engagée et devenez un acteur de la préservation de la biodiversité en France. Parcourez nos fiches, informez-vous sur les enjeux actuels et découvrez comment vous pouvez contribuer directement à la protection des animaux et à la résolution des problèmes environnementaux. Ensemble, faisons de chaque visite sur notre site un pas de plus vers un avenir durable pour nos créatures et notre planète.</p>
            <img src="img/image3.png" alt="Image 3">
        </div>
    </section>
    <div class="container">
    </br>
    </br>
    </br>
    </br>
    </br>
    </br>
    </br>
    </br>
        <div class="boutons">
            <?php include 'Bouton-test.php'; ?>
        </div>
        </br>
    </div>
            <?php
        $mediaResponse = '';
        if (isset($_GET['animalId'])) {
            $animalId = $_GET['animalId'];
            $apiUrl = "https://taxref.mnhn.fr/api/taxa/$animalId/media";

            $mediaResponse = file_get_contents($apiUrl);

            if ($mediaResponse) {
                $mediaData = json_decode($mediaResponse, true);

                if (isset($mediaData['_embedded']['media']) && count($mediaData['_embedded']['media']) > 0) {
            //si on a pas de média, on affiche un message

            echo '<h2>Médias de l\'animal</h2>';
            echo '<div class="carousel">';
            echo '<div class="carousel-inner">';
                foreach ($mediaData['_embedded']['media'] as $media) {
                echo '<div class="carousel-item">';
                    echo '<img src="' . $media['_links']['thumbnailFile']['href'] . '" alt="Image">';
                    echo '<p>Copyright: ' . $media['copyright'] . '</p>';
                    echo '<p>Licence: ' . $media['licence'] . '</p>';
                    echo '</div>';
                }
                echo '</div>';
            echo '<a class="prev" onclick="plusSlides(-1)">❮</a>';
            echo '<a class="next" onclick="plusSlides(1)">❯</a>';
            echo '</div>';
            } else {
            echo '<p>Aucun média trouvé pour cet animal.</p>';
            }
            } else {
            echo '<p>Erreur lors de la requête API.</p>';
            }
            }
            ?>
        </div>
        <br>
        <div style="text-align:center">
            <?php
            //affichage des points seulement si on a des médias
            if (isset($mediaData['_embedded']['media']) && count($mediaData['_embedded']['media']) > 0) {
                echo '<span class="dot" onclick="currentSlide(1)"></span>';
                echo '<span class="dot" onclick="currentSlide(2)"></span>';
                echo '<span class="dot" onclick="currentSlide(3)"></span>';
            }
            ?>
        </div>
        </div>
    </section>
</main>

<footer>
    <div class="bloc-bas">
    <p>&copy; 2024 Biopedia. All rights reserved.
    </br>
    </br> Site réalisé dans le cadre d'un projet universitaire par : 
    </br> Ouissal Jarrari, Axelle Peenaert, Arwin Nirmaladas, Axel Alves
    </p>
    </div>
</footer>



<script>
    showSlides();
    let slideIIndex = 1;
    showwSlides(slideIIndex);

    function plusSlides(n) {
        showwSlides(slideIndex += n);
    }

    function currentSlide(n) {
        showwSlides(slideIndex = n);
    }

    function showwSlides(n) {
        let i;
        let slides = document.getElementsByClassName("carousel-item");
        let dots = document.getElementsByClassName("dot");
        if (n > slides.length) {slideIndex = 1}
        if (n < 1) {slideIndex = slides.length}
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex-1].style.display = "block";
        dots[slideIndex-1].className += " active";
    }
</script>
</body>
</html>